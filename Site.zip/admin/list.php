<?php

include('../ic/header.php');
$bdd = new PDO("mysql:host=mysql.hostinger.fr;dbname=u456157004_admin;charset=utf8", "u456157004_admin", "minecraft95");

$articles = $bdd->query('SELECT * FROM articles ORDER BY date_time_publication DESC')

?>

<!DOCTYPE html>
<html>
<head>
	<title>Artcle</title>
	<meta charset="utf-8">
</head>
<body>
<ul>
      <?php while($a = $articles->fetch()) { ?>
      <li><a class="btn btn-primary" href="#"><?= $a['titre'] ?></a> <a href="redaction.php?edit=<?= $a['id'] ?>" class='btn btn-warning'>Modifier</a>  <a href="delete.php?id=<?= $a['id'] ?>" class='btn btn-danger'>Suprimer</a><br /></li>

      <?php } ?>
</ul>
</body>