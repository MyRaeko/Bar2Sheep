<?php
include('../ic/header.php')
?>
<center>
<a href="redaction.php" class="btn btn-success">Ajouter un article</a><br />
<a href="list.php" class="btn btn-info">Liste des articles</a>

</center>
