<?php
$bdd = new PDO("mysql:host=mysql.hostinger.fr;dbname=u456157004_admin;charset=utf8", "u456157004_admin", "minecraft95");

if(isset($_GET['id']) AND !empty($_GET['id'])) {
   $suppr_id = htmlspecialchars($_GET['id']);
   $suppr = $bdd->prepare('DELETE FROM articles WHERE id = ?');
   $suppr->execute(array($suppr_id));
   header('Location: http://myraeko.esy.es');
}
?>