<?php
$lecture = new Lire('modele/config/config.yml');
$lecture = $lecture->GetTableau();
?>