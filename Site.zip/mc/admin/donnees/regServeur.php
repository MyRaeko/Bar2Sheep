<?php

$lecture = new Lire('modele/config/configServeur.yml');
$lecture = $lecture->GetTableau();


?>