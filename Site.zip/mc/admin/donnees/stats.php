<?php
$lectureStats = new Lire('modele/config/config.yml');
$lectureStats = $lectureStats->GetTableau();

?>
