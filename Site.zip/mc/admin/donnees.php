<?php
require_once('donnees/general.php'); 
require_once('donnees/accueil.php'); 
require_once('donnees/regServeur.php'); 
require_once('donnees/serveur.php'); 
require_once('donnees/pages.php'); 
require_once('donnees/news.php'); 
require_once('donnees/boutique.php'); 
require_once('donnees/menu.php'); 
require_once('donnees/membres.php'); 
require_once('donnees/membres.php'); 
						  
						  ?>