<?php
if($_GET['plugin'] == 'stats')
{
    require_once('stats.php');
}
?>
