<?php

include('ic/header.php');
$bdd = new PDO("mysql:host=mysql.hostinger.fr;dbname=u456157004_admin;charset=utf8", "u456157004_admin", "minecraft95");

$articles = $bdd->query('SELECT * FROM articles ORDER BY date_time_publication DESC')

?>

<!DOCTYPE html>
<html>
<head>
	<title>Artcle</title>
	<meta charset="utf-8">
</head>
<body>
<ul>
      <?php while($a = $articles->fetch()) { ?>
      <div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title"><a href="article.php?id=<?= $a['id'] ?>" class="btn btn-link btn-xs"><?= $a['titre'] ?></a></h3>
  </div>
</div>
<br />
      <?php } ?>
</ul>
</body>
</html>