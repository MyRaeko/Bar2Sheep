<?php
include('ic/header.php');
require_once "jbbcode/Parser.php";
$bdd = new PDO("mysql:host=mysql.hostinger.fr;dbname=u456157004_admin;charset=utf8", "u456157004_admin", "minecraft95");


$parser = new JBBCode\Parser();
$parser->addCodeDefinitionSet(new JBBCode\DefaultCodeDefinitionSet());
 
print $parser->getAsHtml();
if (isset($_GET['id']) AND !empty($_GET['id'])){
	$get_id = htmlspecialchars($_GET['id']);

	$article = $bdd->prepare('SELECT * FROM articles WHERE id = ?');
	$article->execute(array($get_id));

	if ($article->rowCount() == 1) {
		$article = $article->fetch();
		$titre = $article['titre'];
		$contenu = $article['contenu'];
	} else {
		die('Cette article n\'existe pas !');
	}


} else {
	header('Location : index.php');
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Article</title>
	<meta charset="utf-8">
</head>
<body>
	
	<h1><?= $titre ?></h1>
	<br />
	<h5><?php 
	$parser->parse($article['contenu']);
 	print $parser->getAsHtml();?></h5>

</body>
</html>